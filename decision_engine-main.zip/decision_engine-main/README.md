# Decision Engine

## About 

Code and notebooks detailing the supplier selection problem

## TODO

- [ ] Improve the computational performance
- [ ] Finalise the data structures
- [ ] Add visualisation functionality 
- [ ] Add unit tests